﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai2._8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);

            int tong = a + b;
            txtKetQua.Text = ( a + b ).ToString();

            MessageBox.Show("Tong = " + tong);
        }

        private void btnHieu_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            
            int hieu = a - b;
            txtKetQua.Text = ( a - b ).ToString();
            MessageBox.Show("Hieu = " + hieu);
        }

        private void btnTich_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);

            int tich = a * b;
            txtKetQua.Text = ( a * b ).ToString();

            MessageBox.Show("Tich = " + tich);
        }

        private void btnThuong_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);

            int thuong = a / b;
            txtKetQua.Text= ( a / b ).ToString();

            MessageBox.Show("Thuong = " + thuong);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
